import React from 'react';

class DynamicFolderSide extends React.Component {
    render() {
        return (
            <div className="left">
                This is the left!
            </div>
        )
    }
}

export default DynamicFolderSide;