import React from 'react';

class DynamicNoteContent extends React.Component {
    render() {
        return (
            <div className="right">
                Dynamic Note Route
            </div>
        )
    }
}

export default DynamicNoteContent;