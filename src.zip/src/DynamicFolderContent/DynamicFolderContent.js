import React from 'react';

class DynamicFolderContent extends React.Component {
    render() {
        return (
            <div className="right">
                Dynamic Folder Route
            </div>
        )
    }
}

export default DynamicFolderContent;